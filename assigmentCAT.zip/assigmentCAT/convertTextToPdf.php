<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['inputFile']) && isset($_POST['conversionType'])) {
    $inputFile = $_FILES['inputFile']['tmp_name'];
    $conversionType = $_POST['conversionType'];
    $outputFile = 'output.' . ($conversionType === 'textToPDF' ? 'pdf' : 'txt');

    $command = 'java -cp /path/to/pdfbox.jar org.example.PDFConverter ' . escapeshellarg($inputFile) . ' ' . escapeshellarg($outputFile) . ' ' . escapeshellarg($conversionType);
    exec($command, $output, $returnVar);

    if ($returnVar === 0) {
        echo "Conversion completed successfully.";
    } else {
        echo "Error occurred during conversion.";
    }
} else {
    echo "Invalid request";
}
?>