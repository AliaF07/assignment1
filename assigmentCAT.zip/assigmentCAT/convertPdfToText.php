<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['inputFile'])) {
    $inputFile = $_FILES['inputFile']['tmp_name'];
    $outputFile = 'output.txt';

    $command = 'java -cp /path/to/pdfbox.jar org.example.PDFConverter ' . escapeshellarg($inputFile) . ' ' . escapeshellarg($outputFile) . ' pdfToText';
    exec($command, $output, $returnVar);

    if ($returnVar === 0) {
        // Send the output file as a download
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($outputFile) . '"');
        readfile($outputFile);

        // Delete the output file after download
        unlink($outputFile);
    } else {
        echo "Error occurred during PDF to TXT conversion.";
    }
} else {
    echo "Invalid request";
}
?>